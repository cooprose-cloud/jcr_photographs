---
title: The Dog next door.
--- 
I once did a series of photographs on the pets  . . . .