---
title: A Regal Cat upon the Grand Piano.
--- 
This cat was aloft and looked down at her world. . . . .