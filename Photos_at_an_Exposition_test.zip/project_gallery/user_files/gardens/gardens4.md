---
title: Flying Dogwoods
--- 
In early spring in the south, the dogwoods burst into beautiful trees. I thought these dogwood flowers loked like they were happily flying . . . .