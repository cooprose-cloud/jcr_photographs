# Start Here — Photos at an Exposition (test copy)

Thanks for trying this out! It turns folders of photographs into a small
website you can open in any browser. Below is the quick path to see it working.
The complete guide — captions, options, troubleshooting, and a full worked
example — is in **USER_MANUAL.md**.

## 1. One-time setup: Python + Pillow

You need **Python 3.9 or later** and the **Pillow** image library.

**On a Mac** (Python 3 is usually already installed):

    python3 --version
    pip3 install Pillow

**On Windows:**

1. Install Python from https://python.org — in the installer, tick
   **"Add Python to PATH"**.
2. Then, in Command Prompt or PowerShell:

        python --version
        pip install Pillow

> Throughout the manual, where Mac instructions say `python3`, `pip3`, or
> `open`, on Windows you type `python` (or `py`), `pip`, and `start` instead.

## 2. See the example site (about 2 minutes)

Open a terminal and move into this folder — the one that contains `scripts/`
and `user_files/`. Then run:

**Mac / Linux**

    python3 scripts/generate_photo_config.py --user-dir user_files --form
    python3 scripts/photos_exposition.py user_files/photo_config.json --clean
    open website/index.html

**Windows**

    python scripts\generate_photo_config.py --user-dir user_files --form
    python scripts\photos_exposition.py user_files\photo_config.json --clean
    start website\index.html

A browser should open showing two galleries — **Gardens** and **Pets** — with
a rotating slideshow, thumbnail pages, click-to-zoom photos, and "Read More"
pages.

## 3. Go deeper, then try your own photos

Follow **section 3.5, "A worked example, start to finish"** in USER_MANUAL.md
to add captions, choose slideshow photos, and use the validator. Then drop your
own photos into new folders under `user_files/` and rebuild.

## What to send back to Dad

A few notes would help a lot:

- Which computer / OS and Python version you used.
- Anywhere you got stuck or confused — especially the setup in step 1.
- Anything that broke (paste the exact error text if you can).
- What felt good, and what you'd change.

Thanks for testing!
